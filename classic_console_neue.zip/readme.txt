Classic Console Neue (aka. Classic Console v2) TrueType Font (ttf)
Original 8x16 ASCII Console Fixed Width Font including many code pages (latin, cyrillic, greek, hebrew, braille, armenian, georgian, ethiopic, arab, etc) (retro old console terminal vga bios ms dos font). Currently counting 4100 glyphs.
Useful as command line font, FAR Manager, Putty, VS Code font, IntelliJ, WebStorm/PHPStorm, other IDE/source code editing tools, etc. Best viewed in 12pt (16px).

License: MIT, Copyright © 2011-2021, deejayy.hu

http://twitter.com/deejayyhu

https://webdraft.eu/

